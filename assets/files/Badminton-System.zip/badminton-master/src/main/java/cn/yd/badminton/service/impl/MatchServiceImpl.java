package cn.yd.badminton.service.impl;

import cn.yd.badminton.service.MatchService;
import cn.yd.badminton.mapper.MatchMapper;
import cn.yd.badminton.po.Match;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MatchServiceImpl implements MatchService {

    @Autowired
    private MatchMapper matchMapper;

    @Override
    @Transactional
    public void insertMatch(Match match) throws Exception {
        matchMapper.insert(match);
    }
}
