package cn.yd.badminton.po;

public class Match {
    private int match_ID;
    private int user1_ID;
    private int user2_ID;
    private String match_date;
    private String stage;
    private String result;

    // constructor
    public Match(int match_ID, int user1_ID, int user2_ID, String match_date, String stage, String result) {
        this.match_ID = match_ID;
        this.user1_ID = user1_ID;
        this.user2_ID = user2_ID;
        this.match_date = match_date;
        this.stage = stage;
        this.result = result;
    }

    // getters and setters
    public int getMatch_ID() {
        return match_ID;
    }

    public void setMatch_ID(int match_ID) {
        this.match_ID = match_ID;
    }

    public int getUser1_ID() {
        return user1_ID;
    }

    public void setUser1_ID(int user1_ID) {
        this.user1_ID = user1_ID;
    }

    public int getUser2_ID() {
        return user2_ID;
    }

    public void setUser2_ID(int user2_ID) {
        this.user2_ID = user2_ID;
    }

    public String getMatch_date() {
        return match_date;
    }

    public void setMatch_date(String match_date) {
        this.match_date = match_date;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
