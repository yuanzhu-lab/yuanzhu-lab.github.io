package cn.yd.badminton.service;

import cn.yd.badminton.po.Match;

public interface MatchService {
    public void insertMatch(Match match) throws Exception;
}
