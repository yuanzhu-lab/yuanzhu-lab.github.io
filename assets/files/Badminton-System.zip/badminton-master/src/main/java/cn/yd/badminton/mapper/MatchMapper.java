package cn.yd.badminton.mapper;

import cn.yd.badminton.po.Match;

public interface MatchMapper {
    int deleteByPrimaryKey(Integer match_ID);

    int insert(Match record);

    int insertSelective(Match record);

    Match selectByPrimaryKey(Integer match_ID);

    int updateByPrimaryKeySelective(Match record);

    int updateByPrimaryKey(Match record);
}
