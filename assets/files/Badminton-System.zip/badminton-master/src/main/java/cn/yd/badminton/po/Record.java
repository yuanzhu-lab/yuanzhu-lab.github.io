package cn.yd.badminton.po;

public class Record {
    private int record_ID;
    private int match_ID;
    private int user1_score;
    private int user2_score;
    private String description;

    // constructor
    public Record(int record_ID, int match_ID, int user1_score, int user2_score, String description) {
        this.record_ID = record_ID;
        this.match_ID = match_ID;
        this.user1_score = user1_score;
        this.user2_score = user2_score;
        this.description = description;
    }

    // getters and setters
    public int getRecord_ID() {
        return record_ID;
    }

    public void setRecord_ID(int record_ID) {
        this.record_ID = record_ID;
    }

    public int getMatch_ID() {
        return match_ID;
    }

    public void setMatch_ID(int match_ID) {
        this.match_ID = match_ID;
    }

    public int getUser1_score() {
        return user1_score;
    }

    public void setUser1_score(int user1_score) {
        this.user1_score = user1_score;
    }

    public int getUser2_score() {
        return user2_score;
    }

    public void setUser2_score(int user2_score) {
        this.user2_score = user2_score;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
