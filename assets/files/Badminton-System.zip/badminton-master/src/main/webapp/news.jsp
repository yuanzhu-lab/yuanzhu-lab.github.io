<%-- Created by IntelliJ IDEA. User: Jerry Date: 2022/12/24 Time: 21:35 To change this template use File | Settings |
    File Templates. --%>
    <%@ page contentType="text/html; charset=UTF-8" language="java" %>
        <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
            <%@ include file="include/fore/foreHeader.jsp" %>
                <link rel="stylesheet" href="${pageContext.request.contextPath}/css/fore/news.css">
                <style>
                    body>div {
                        background: transparent url('${pageContext.request.contextPath}/image/fore/homepage.jpg') no-repeat center center / cover fixed !important;
                    }

                    .sub-ul {
                        margin: 20px;
                    }

                    .sub-ul li {
                        line-height: 29px;
                        border-bottom: 1px dashed #ddd;
                        padding: 0 5px 0 20px;
                    }

                    .sub-ul a {
                        width: 370px;
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        text-decoration: none;
                        cursor: pointer;
                        color: #666;
                    }
                </style>
                </head>
                <%@ include file="include/fore/foreNavigator.jsp" %>
                    <title>俱乐部新闻</title>
                    <!-- tab标签开始 -->
                    <div id="wrapper" style="margin-top: 20px">


                        <div class="sub-content" style="margin: 20px 0; font-size: small">
                            <div class="position-bar">
                                当前位置: 新闻
                            </div>
                            <div class="sub-ul">
                                <ul style="font-size: 13px;line-height: 30px">
                                    <li>
                                        <span style="color: #00AAEE">>>&nbsp;&nbsp;<a
                                                href="${pageContext.request.contextPath}/jump/ToNewsShow">新闻</a></span>
                                    </li>
                                    <%-- <c:forEach items="${newsList}" var="n">--%>
                                        <%-- <li>--%>
                                            <%-- <span style="color: #00AAEE">>>&nbsp;&nbsp;<a
                                                    href="forenewsShow?nid=${n.id}">${n.title}</a></span>--%>
                                                <%-- <span style="float: right;">${n.TIMEX}</span>--%>
                                                    <%-- </li>--%>
                                                        <%-- </c:forEach>--%>
                                </ul>
                            </div>

                        </div>

                        <!-- tab标签结束 -->

                    </div>



                    </div>
                    </div>
                    <%@include file="include/fore/foreFooter.jsp" %>