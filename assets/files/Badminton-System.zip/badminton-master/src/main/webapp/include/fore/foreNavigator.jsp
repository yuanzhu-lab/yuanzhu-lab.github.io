<%-- Created by IntelliJ IDEA. User: Jerry Date: 2018/12/21 Time: 22:22 To change this template use File | Settings |
    File Templates. --%>

    <%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>

        <body>
            <!-- header开始 -->
            <div class="header-area" style="background-color: #f0f0f0; height: 55px">
                <div class="container h-100">
                    <div class="h-100 d-flex justify-content-between align-items-center">
                        <div class="p-2">
                            <a href="${pageContext.request.contextPath}/jump/ToHome"><img
                                    src="${pageContext.request.contextPath}/image/fore/logo.jpg" width="275"></a>
                        </div>

                        <c:if test="${empty userR}">
                            <div class="p-2">
                                <a href="${pageContext.request.contextPath}/jump/ToRegister"
                                    style="color: #666; text-decoration: none; font-size: 14px;font-weight: 400">注册</a>
                                <span>|</span>
                                <a href="${pageContext.request.contextPath}/jump/ToLogin"
                                    style="color: #666; text-decoration: none;font-size: 14px;font-weight: 400">登录</a>
                            </div>
                        </c:if>
                        <c:if test="${!empty userR}">
                            <div class="p-2">
                                <a href="${pageContext.request.contextPath}/user/searchReservation?userId=${userR.userId}"
                                    style="color: #666; text-decoration: none;font-size: 14px;font-weight: 400">个人中心</a>
                                <span>|</span>
                                <a href="${pageContext.request.contextPath}/jump/LoginOut"
                                    style="color: #666; text-decoration: none;font-size: 14px;font-weight: 400">退出</a>
                            </div>
                        </c:if>

                    </div>
                </div>
            </div>

            <div style="background-color: #f0f0f0; min-height: 670px">
                <div class="container">
                    <div id="nav-main">
                        <ul class="nav-inner-box">
                            <li><a id="home.jsp" href="${pageContext.request.contextPath}/jump/ToHome"
                                    style="font-weight: 400">首页</a></li>
                            <li><a id="introduce.jsp" href="${pageContext.request.contextPath}/jump/ToIntroduce"
                                    style="font-weight: 400">场地介绍</a></li>
                            <li><a id="book.jsp" href="${pageContext.request.contextPath}/user/searchAreaReservation"
                                    style="font-weight: 400">场地预约</a></li>
                            <li><a id="news.jsp" href="${pageContext.request.contextPath}/jump/ToNews"
                                    style="font-weight: 400">公告</a></li>
                        </ul>
                    </div>

                    <% String where=request.getPathInfo(); if (where==null) { where="home.jsp" ; } %>

                        <script>
                            document.getElementById("<%= where %>").style.background = "gray no-repeat center bottom";
                            document.getElementById("<%= where %>").style.color = "#fff";
                        </script>