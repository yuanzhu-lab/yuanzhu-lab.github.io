<%--
  Created by IntelliJ IDEA.
  User: Jerry
  Date: 2022/12/26
  Time: 23:22
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>welcome</title>
</head>
<body>
    <a href="${pageContext.request.contextPath}/jump/ToHome"></a>
    <script>
        document.getElementsByTagName("a")[0].click();
    </script>
</body>
</html>
