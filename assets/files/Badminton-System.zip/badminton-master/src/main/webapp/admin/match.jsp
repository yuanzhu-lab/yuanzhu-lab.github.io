<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" import="java.util.*" %>

    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
        <%@ include file="../include/admin/adminHeader.jsp" %>
            <%@ include file="../include/admin/adminNavigator.jsp" %>

                <script>
                    $(function () {
                        $("#addForm").submit(function () {
                            if (!checkEmpty("match_id", "Match ID"))
                                return false;
                            if (!checkEmpty("user1_id", "User1 ID"))
                                return false;
                            if (!checkEmpty("user2_id", "User2 ID"))
                                return false;
                            if (!checkEmpty("match_date", "Match Date"))
                                return false;
                            if (!checkEmpty("stage", "Stage"))
                                return false;
                            if (!checkEmpty("result", "Result"))
                                return false;
                            return true;
                        });
                    });
                </script>

                <div class="workingArea">

                    <div class="panel panel-warning addDiv">
                        <div class="panel-heading">Add Match</div>
                        <div class="panel-body">
                            <form method="post" id="addForm"
                                action="${pageContext.request.contextPath}/Administrator/insertMatch"
                                enctype=" multipart/form-data">
                                <table class="addTable">
                                    <tr>
                                        <td>Match ID</td>
                                        <td><input id="match ID" name="match_ID" type="text" class="form-control" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>User1 ID</td>
                                        <td><input id="user1_ID" name="user1_ID" type="text" class="form-control" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>User2 ID</td>
                                        <td><input id="user2_ID" name="user2_ID" type="text" class="form-control" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Match date</td>
                                        <td><input id="match_date" name="match_date" type="date" class="form-control" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Stage</td>
                                        <td><input id="stage" name="stage" type="text" class="form-control" /></td>
                                    </tr>
                                    <tr>
                                        <td>Result</td>
                                        <td><input id="result" name="result" type="text" class="form-control" /></td>
                                    </tr>
                                    <tr class="submitTR">
                                        <td colspan="2" align="center">
                                            <button type="submit" class="btn btn-success">Submit</button>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        </div>
                    </div>
                </div>

                <%@ include file="../include/admin/adminFooter.jsp" %>