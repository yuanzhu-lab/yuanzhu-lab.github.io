@ECHO off

pip install -r requirements.txt

python src/vqa.py

pause