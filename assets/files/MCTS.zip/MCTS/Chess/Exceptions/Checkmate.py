class Checkmate(Exception):
    pass