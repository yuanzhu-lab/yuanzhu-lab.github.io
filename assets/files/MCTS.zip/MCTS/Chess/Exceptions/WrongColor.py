class WrongColor(Exception):
    pass